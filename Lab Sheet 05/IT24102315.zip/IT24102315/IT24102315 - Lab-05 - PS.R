setwd("D:\\Lab 05-20250829")
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = " ")

names(DeliveryTimes) <- c("Times")

fix(DeliveryTimes)

attach(DeliveryTimes)

breaks <- seq(20, 70, length.out = 10)


hist(Times, breaks = breaks, right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")

hist_obj <- hist(Times, breaks = breaks, right = FALSE, plot = FALSE)
cum.freq <- cumsum(hist_obj$counts)

new <- c(0)
for(i in 1:length(breaks)){
  if(i == 1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i - 1]
  }
}

plot(breaks, new, type = "l",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time", ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

cbind(Upper = breaks, CumFreq = new)